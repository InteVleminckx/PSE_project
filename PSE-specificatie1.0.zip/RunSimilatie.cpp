/*
 * korte beschrijving:
 * main file om de simulatie uit te voeren.
 * @author: Inte Vleminckx en Karnaukh Maksim
 * @date: 18/03/2021
 * @version: Specificatie 1.0
*/

#include "FileParser.h"
#include "Transport.h"

int main(){

    string file = "../test-bestanden/systemFiles/systemTest"
                  "1.xml"; // bestand dat wordt uitgevoerd in de main
    FileParser parsedFile;
    parsedFile.parseFile(file);
    parsedFile.uitvoer(); // uitvoer(bestand) aan begin van de simulatie.
    Transport transport(parsedFile);
    parsedFile.uitvoer(false); // uitvoer(bestand) aan einde van de simulatie.

    return 0;
}
